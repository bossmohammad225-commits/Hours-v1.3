# Hours v1.3

This project is prepared from the Hours v1.2 project for the v1.3 build.

## Build
Use a standard Android/Gradle build environment and build the debug APK with:

`./gradlew assembleDebug`

The APK will normally be produced under the app module's `build/outputs/apk/` directory.

## Important
This ZIP is a source project, not an APK. An Android SDK + Gradle build environment is required to compile it.
