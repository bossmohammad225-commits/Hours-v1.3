package com.hours.app
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FlightDao {
    @Query("SELECT * FROM flights ORDER BY date DESC, id DESC")
    fun observeAll(): Flow<List<Flight>>
    @Query("SELECT * FROM flights ORDER BY date DESC, id DESC")
    suspend fun getAll(): List<Flight>
    @Insert
    suspend fun insert(flight: Flight)
    @Insert
    suspend fun insertAll(flights: List<Flight>)
    @Query("DELETE FROM flights")
    suspend fun deleteAll()
    @Delete
    suspend fun delete(flight: Flight)
}
