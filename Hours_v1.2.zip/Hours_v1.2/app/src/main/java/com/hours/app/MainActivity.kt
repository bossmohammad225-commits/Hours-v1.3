package com.hours.app

import android.accounts.Account
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.services.drive.DriveScopes
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime

class MainActivity : ComponentActivity() {
    private lateinit var db: HoursDatabase
    private lateinit var driveBackup: DriveBackup

    private val signInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            task.getResult(ApiException::class.java)
        } catch (_: Exception) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Room.databaseBuilder(applicationContext, HoursDatabase::class.java, "hours.db").build()
        driveBackup = DriveBackup(this)
        setContent { HoursApp(db.flightDao(), driveBackup, ::signInGoogle) }
    }

    private fun signInGoogle() {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DriveScopes.DRIVE_FILE))
            .build()
        signInLauncher.launch(GoogleSignIn.getClient(this, options).signInIntent)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HoursApp(dao: FlightDao, drive: DriveBackup, signIn: () -> Unit) {
    val scope = rememberCoroutineScope()
    val flights by dao.observeAll().collectAsState(initial = emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var add by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val account = GoogleSignIn.getLastSignedInAccount(androidx.compose.ui.platform.LocalContext.current)
    val today = LocalDate.now().toString()
    val month = today.substring(0, 7)
    val monthFlights = flights.filter { it.date.startsWith(month) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Hours") }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary, titleContentColor = MaterialTheme.colorScheme.onPrimary)) },
        floatingActionButton = { FloatingActionButton(onClick = { add = true }) { Text("+") } },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, icon = { Text("⌂") }, label = { Text("Dashboard") })
                NavigationBarItem(tab == 1, { tab = 1 }, icon = { Text("▣") }, label = { Text("Flights") })
                NavigationBarItem(tab == 2, { tab = 2 }, icon = { Text("▤") }, label = { Text("Monthly") })
                NavigationBarItem(tab == 3, { tab = 3 }, icon = { Text("☁") }, label = { Text("Cloud") })
            }
        }
    ) { padding ->
        when (tab) {
            0 -> Dashboard(Modifier.padding(padding), flights.filter { it.date == today }.sumOf { it.minutes }, monthFlights.sumOf { it.minutes }, monthFlights)
            1 -> FlightList(Modifier.padding(padding), flights) { scope.launch { dao.delete(it) } }
            2 -> Monthly(Modifier.padding(padding), flights)
            3 -> Cloud(Modifier.padding(padding), account, flights, dao, drive, signIn) { message = it }
        }
    }
    if (message.isNotEmpty()) {
        LaunchedEffect(message) { kotlinx.coroutines.delay(2200); message = "" }
        SnackbarHost(remember { SnackbarHostState() }, modifier = Modifier.padding(16.dp))
    }
    if (add) AddFlightDialog({ add = false }) { scope.launch { dao.insert(it); add = false } }
}

@Composable
fun Dashboard(modifier: Modifier, today: Long, month: Long, mf: List<Flight>) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("FLIGHT OPERATIONS", style = MaterialTheme.typography.labelLarge); Text("Flying Hours", style = MaterialTheme.typography.headlineMedium) }
        item { StatCard("Today", fmt(today)) }; item { StatCard("This Month", fmt(month)) }
        item { StatCard("Monthly Flights", mf.size.toString()) }
        item { StatCard("Turn Around", mf.count { it.flightType == "Turn Around" }.toString()) }
        item { StatCard("Layover", mf.count { it.flightType == "Layover" }.toString()) }
    }
}
@Composable fun StatCard(t: String, v: String) { Card { Row(Modifier.fillMaxWidth().padding(18.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text(t, style = MaterialTheme.typography.titleMedium); Text(v, style = MaterialTheme.typography.headlineSmall) } } }

@Composable
fun FlightList(modifier: Modifier, flights: List<Flight>, onDelete: (Flight) -> Unit) {
    if (flights.isEmpty()) { Box(modifier.fillMaxSize(), Alignment.Center) { Text("No flights recorded yet.") }; return }
    LazyColumn(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(flights) { f -> Card { Row(Modifier.fillMaxWidth().padding(16.dp), Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(f.flightNo, style = MaterialTheme.typography.titleMedium); Text("${f.date} • ${f.route}"); Text("${f.departure} → ${f.arrival} • ${fmt(f.minutes)}"); Text(f.flightType, style = MaterialTheme.typography.labelLarge) }
            TextButton({ onDelete(f) }) { Text("Delete") }
        } } }
    }
}

@Composable
fun Monthly(modifier: Modifier, flights: List<Flight>) {
    val groups = flights.groupBy { it.date.substring(0,7) }.toSortedMap(reverseOrder())
    LazyColumn(modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (groups.isEmpty()) item { Text("No monthly data yet.") }
        groups.forEach { (m, list) -> item { Card { Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text(m, style = MaterialTheme.typography.titleLarge); Text("Total: ${fmt(list.sumOf { it.minutes })}"); Text("Flights: ${list.size}")
            Text("Turn Around: ${list.count { it.flightType == "Turn Around" }}"); Text("Layover: ${list.count { it.flightType == "Layover" }}")
        } } } }
    }
}

@Composable
fun Cloud(modifier: Modifier, account: Account?, flights: List<Flight>, dao: FlightDao, drive: DriveBackup, signIn: () -> Unit, notify: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Cloud Backup", style = MaterialTheme.typography.headlineMedium)
        Text(if (account == null) "Connect Google Drive to back up your flying records." else "Connected: ${account.name}")
        Button(onClick = { signIn() }) { Text(if (account == null) "Connect Google Drive" else "Change Google Account") }
        Button(enabled = account != null, onClick = { account?.let { a -> scope.launch { runCatching { drive.backup(a, flights); notify("Backup complete") }.onFailure { notify("Backup failed") } } } }) { Text("Backup Now") }
        Button(enabled = account != null, onClick = { account?.let { a -> scope.launch { runCatching { val data = drive.restore(a); dao.deleteAll(); dao.insertAll(data); notify("Restore complete") }.onFailure { notify("Restore failed") } } } }) { Text("Restore from Google Drive") }
        Text("The backup is saved as Hours_flying_hours_backup.json in your Google Drive.")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFlightDialog(onDismiss: () -> Unit, onAdd: (Flight) -> Unit) {
    var no by remember { mutableStateOf("") }; var route by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }; var dep by remember { mutableStateOf("09:00") }; var arr by remember { mutableStateOf("11:00") }
    var type by remember { mutableStateOf("Turn Around") }; var expanded by remember { mutableStateOf(false) }; var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add Flight") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(no, { no = it }, label = { Text("Flight number") }, singleLine = true)
            OutlinedTextField(route, { route = it }, label = { Text("Route") }, singleLine = true)
            OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, singleLine = true)
            OutlinedTextField(dep, { dep = it }, label = { Text("Departure (HH:MM)") }, singleLine = true)
            OutlinedTextField(arr, { arr = it }, label = { Text("Arrival (HH:MM)") }, singleLine = true)
            ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
                OutlinedTextField(type, {}, readOnly = true, label = { Text("Flight type") }, modifier = Modifier.menuAnchor())
                ExposedDropdownMenu(expanded, { expanded = false }) { listOf("Turn Around","Layover").forEach { x -> DropdownMenuItem({ Text(x) }, { type=x; expanded=false }) } }
            }
            if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { Button({
        try {
            val d=LocalDate.parse(date); val dp=LocalTime.parse(dep); val ar=LocalTime.parse(arr)
            if(no.isBlank()||route.isBlank()) throw Exception()
            var mins=Duration.between(dp,ar).toMinutes(); if(mins<0) mins+=1440
            onAdd(Flight(date=d.toString(), flightNo=no.trim(), route=route.trim(), departure=dp.toString(), arrival=ar.toString(), flightType=type, minutes=mins))
        } catch(_:Exception){error="Please check the entered values."}
    }) { Text("Save") } }, dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}
fun fmt(m: Long)="%02dh %02dm".format(m/60,m%60)
