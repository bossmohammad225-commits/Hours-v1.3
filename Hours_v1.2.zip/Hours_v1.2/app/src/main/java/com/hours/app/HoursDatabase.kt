package com.hours.app
import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Flight::class], version = 1, exportSchema = false)
abstract class HoursDatabase : RoomDatabase() {
    abstract fun flightDao(): FlightDao
}
