package com.hours.app

import android.content.Context
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.ByteArrayContent
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File
import com.google.gson.GsonBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.charset.StandardCharsets

class DriveBackup(private val context: Context) {
    companion object {
        private const val BACKUP_NAME = "Hours_flying_hours_backup.json"
        private const val MIME_JSON = "application/json"
    }

    private fun service(account: android.accounts.Account): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            context, listOf(DriveScopes.DRIVE_FILE)
        ).apply { selectedAccount = account }
        return Drive.Builder(
            com.google.api.client.http.javanet.NetHttpTransport(),
            com.google.api.client.json.gson.GsonFactory.getDefaultInstance(),
            credential
        ).setApplicationName("Hours").build()
    }

    suspend fun backup(account: android.accounts.Account, flights: List<Flight>) = withContext(Dispatchers.IO) {
        val drive = service(account)
        val json = GsonBuilder().create().toJson(flights)
        val existing = drive.files().list()
            .setQ("name='$BACKUP_NAME' and trashed=false")
            .setSpaces("drive").setFields("files(id,name)").execute().files.firstOrNull()
        val media = ByteArrayContent(MIME_JSON, json.toByteArray(StandardCharsets.UTF_8))
        if (existing == null) {
            drive.files().create(File().setName(BACKUP_NAME), media).setFields("id").execute()
        } else {
            drive.files().update(existing.id, null, media).execute()
        }
    }

    suspend fun restore(account: android.accounts.Account): List<Flight> = withContext(Dispatchers.IO) {
        val drive = service(account)
        val file = drive.files().list()
            .setQ("name='$BACKUP_NAME' and trashed=false")
            .setSpaces("drive").setFields("files(id,name)").execute().files.firstOrNull()
            ?: return@withContext emptyList()
        val out = java.io.ByteArrayOutputStream()
        drive.files().get(file.id).executeMediaAndDownloadTo(out)
        GsonBuilder().create().fromJson(out.toString("UTF-8"), Array<Flight>::class.java).toList()
    }
}
