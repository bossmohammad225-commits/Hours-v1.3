package com.hours.app
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "flights")
data class Flight(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val flightNo: String,
    val route: String,
    val departure: String,
    val arrival: String,
    val flightType: String,
    val minutes: Long
)
