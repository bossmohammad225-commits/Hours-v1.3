# Hours v1.3 — Google Drive Backup & Restore

This version adds:
- Local Room database for permanent offline storage.
- Google Sign-In.
- Google Drive backup to `Hours_flying_hours_backup.json`.
- Manual Backup Now.
- Restore from Google Drive.
- Turn Around / Layover flight type.
- Monthly statistics.

## Important: Google Cloud setup

The app-side Drive code is included, but Google authentication requires your own Google Cloud configuration.

1. Open Google Cloud Console.
2. Create a project named `Hours`.
3. Enable **Google Drive API**.
4. Configure the OAuth consent screen.
5. Add an Android OAuth client for package name:
   `com.hours.app`
6. Use the SHA-1 certificate fingerprint of your debug/release keystore when creating the Android OAuth client.
7. Download the appropriate Google configuration if Google asks for it and follow the current Android Google Sign-In setup.
8. Build and run the app.

The app requests the restricted-to-app-files Drive scope `drive.file`, so Hours can create/update its own backup file without requesting broad access to every file in Drive.

## Build

Open the project in Android Studio, allow Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s)

Debug APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Restore warning

Restore replaces the current local flight list with the backup contents. Make a backup first if you have newer local records.

## Automatic backup

This v1.2 provides manual Backup Now and Restore. Automatic background synchronization can be added in a later version after the account/auth flow is confirmed on the target device.
